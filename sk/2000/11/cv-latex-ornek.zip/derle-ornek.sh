pdflatex paciorek-cv.tex
"C:/Program Files/Adobe/Acrobat 5.0/Reader/AcroRd32.exe" paciorek-cv.pdf
