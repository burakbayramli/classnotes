
http://www.weather.gov.sg/climate-historical-daily/

wget http://www.weather.gov.sg/files/dailydata/DAILYDATA_S24_202001.csv
